function esPalindromo(word){
  
  // Pasamos la palabra a minúsculas
  let palabra = word.toLowerCase();
  
  // Separamos la palabra letra por letra en un Array
  let array1 = palabra.split("");

  // Le damos la vuelta
  let reversed = array1.reverse();
  
  // La volvemos a unir
  let union = reversed.join("");
  
  // Comprobamos si son iguales
  if(palabra == union){
    return true;
  }else{
    return false;
  }
}

var texto = prompt("Introduce un texto");
document.write(esPalindromo(texto));